document.getElementById("getResponse").addEventListener("click", () => {
  const inputText = document.getElementById("inputText").value.trim();
  if (!inputText) return alert("Please enter some text!");

  const responseDiv = document.getElementById("response");
  responseDiv.textContent = "⏳ Generating response…";

  chrome.storage.local.get(["apiKey", "provider"], async (data) => {
    const apiKey = data.apiKey;
    const provider = data.provider;
    if (!apiKey) {
      responseDiv.textContent = "";
      return alert("API Key not set! Go to Settings.");
    }
    if (provider !== "openrouter") {
      responseDiv.textContent = "";
      return alert("Provider is not set to OpenRouter!");
    }

    try {
      const res = await fetch("https://openrouter.ai/api/v1/chat/completions", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${apiKey}`
        },
        body: JSON.stringify({
          model: "mistralai/mistral-7b-instruct:free",
          messages: [{ role: "user", content: inputText }],
          max_tokens: 200
        })
      });

      const data = await res.json();
      console.log("OpenRouter response:", data);

      if (data.error) {
        responseDiv.textContent = "❌ API Error: " + data.error.message;
        return;
      }

      const text = data?.choices?.[0]?.message?.content || "No response received.";
      responseDiv.textContent = text;

    } catch (err) {
      responseDiv.textContent = "❌ Network/Error: " + err.message;
      console.error(err);
    }
  });
});
