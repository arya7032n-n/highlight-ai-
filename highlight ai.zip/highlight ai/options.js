// options.js - store and load API key + provider
document.addEventListener("DOMContentLoaded", () => {
  chrome.storage.local.get(["apiKey","provider","ocrApiKey"], (data) => {
    if (data.apiKey) document.getElementById("apiKey").value = data.apiKey;
    if (data.provider) document.getElementById("provider").value = data.provider;
    if (data.ocrApiKey) document.getElementById("ocrApiKey").value = data.ocrApiKey;
  });
});

document.getElementById("save").addEventListener("click", () => {
  const apiKey = document.getElementById("apiKey").value.trim();
  const provider = document.getElementById("provider").value;
  const ocrApiKey = document.getElementById("ocrApiKey").value.trim();
  if (!apiKey) {
    document.getElementById("status").textContent = "❌ Please enter your API key.";
    return;
  }
  chrome.storage.local.set({ apiKey, provider, ocrApiKey }, () => {
    document.getElementById("status").textContent = "✅ Settings saved.";
  });
});
