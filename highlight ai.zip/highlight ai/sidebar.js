// sidebar.js - runs when loaded in sidebar.html iframe
(function(){
  const closeBtn = document.getElementById('hai-close');
  const sendBtn = document.getElementById('hai-send');
  const input = document.getElementById('hai-input');
  const respDiv = document.getElementById('hai-response');
  const uploadBtn = document.getElementById('uploadBtn');
  const pdfUpload = document.getElementById('pdfUpload');
  const uploadStatus = document.getElementById('uploadStatus');
  
  let currentChatContext = null;
  // Persistent OCR worker & progress callback
  let __tesseractWorker = null;
  let __tesseractLibLoaded = false;
  // progress callback used by the worker's logger; set during a recognition call
  let __tesseractProgressCb = null;
  // Settings (persisted)
  let settings = {
    fastMode: true,
    ocrMaxWidth: 1200,
    ocrMaxHeight: 1200,
    ocrQuality: 0.8,
    aiTrimChars: 1500,
    aiMaxTokens: 256
  };

  // Load settings from storage and update UI
  chrome.storage.local.get(['fastMode','ocrMaxWidth','ocrMaxHeight','ocrQuality','aiTrimChars','aiMaxTokens'], (data) => {
    if (typeof data.fastMode !== 'undefined') settings.fastMode = !!data.fastMode;
    if (typeof data.ocrMaxWidth === 'number') settings.ocrMaxWidth = data.ocrMaxWidth;
    if (typeof data.ocrMaxHeight === 'number') settings.ocrMaxHeight = data.ocrMaxHeight;
    if (typeof data.ocrQuality === 'number') settings.ocrQuality = data.ocrQuality;
    if (typeof data.aiTrimChars === 'number') settings.aiTrimChars = data.aiTrimChars;
    if (typeof data.aiMaxTokens === 'number') settings.aiMaxTokens = data.aiMaxTokens;
    // reflect in UI
    try { const el = document.getElementById('opt-fast'); if (el) el.checked = !!settings.fastMode; } catch(e){}
  });

  // wire fast toggle change
  try {
    const fastEl = document.getElementById('opt-fast');
    if (fastEl) {
      fastEl.addEventListener('change', (e) => {
        settings.fastMode = !!e.target.checked;
        // adjust aiMaxTokens for fast mode
        settings.aiMaxTokens = settings.fastMode ? 256 : 800;
        chrome.storage.local.set({ fastMode: settings.fastMode, aiMaxTokens: settings.aiMaxTokens });
      });
    }
  } catch (e) {}

  // Upload button handler
  if (uploadBtn) {
    uploadBtn.addEventListener('click', () => {
      pdfUpload.click();
    });
  }

  if (pdfUpload) {
    pdfUpload.addEventListener('change', handlePdfUpload);
  }

  async function handlePdfUpload(e) {
    const file = e.target?.files?.[0];
    if (!file) return;
    
    uploadStatus.textContent = '⏳ Extracting...';

    try {
      const pdfjsLib = await import(chrome.runtime.getURL('pdfjs/pdf.mjs'));
      try {
        pdfjsLib.GlobalWorkerOptions.workerSrc = chrome.runtime.getURL('pdfjs/pdf.worker.mjs');
      } catch {}

      const arrayBuf = await file.arrayBuffer();
      const pdf = await pdfjsLib.getDocument({ data: arrayBuf }).promise;
      let fullText = '';
      for (let i = 1; i <= pdf.numPages; i++) {
        const page = await pdf.getPage(i);
        const content = await page.getTextContent();
        fullText += content.items.map(it => it.str).join(' ') + '\n\n';
      }

      const chunks = chunkText(fullText);
      const doc = { id: 'doc_' + Date.now(), name: file.name, chunks };
      chrome.storage.local.get(['rag_docs'], (data) => {
        const arr = data.rag_docs || [];
        arr.push(doc);
        chrome.storage.local.set({ rag_docs: arr }, () => {
          uploadStatus.textContent = `✅ ${file.name} (${chunks.length} chunks)`;
        });
      });
    } catch (err) {
      uploadStatus.textContent = '❌ Failed';
      console.error(err);
    }
    
    // Reset file input
    pdfUpload.value = '';
  }

  function chunkText(text, size = 1000, overlap = 200) {
    const chunks = [];
    let i = 0;
    while (i < text.length) {
      chunks.push(text.slice(i, i + size).trim());
      i += size - overlap;
    }
    return chunks;
  }

  // Close handler
  if (closeBtn) {
    closeBtn.addEventListener('click', () => {
      if (window !== window.top) {
        try { parent.postMessage({ type: 'CLOSE_SIDEBAR' }, '*'); } catch (e) {}
      }
      try { window.close(); } catch (e) {}
    });
  }

  // Paste handler for images
  document.addEventListener('paste', handlePaste);

  async function handlePaste(e) {
    const items = e.clipboardData?.items;
    if (!items) return;
    
    for (const item of items) {
      if (item.type.startsWith('image/')) {
        const blob = item.getAsFile();
        const url = URL.createObjectURL(blob);
        insertPastedImage(url, blob);
      }
    }
  }

  function insertPastedImage(url, blob) {
    const wrapper = document.createElement('div');
    wrapper.style.cssText = 'margin: 10px 0; padding: 10px; background: rgba(255,255,255,0.02); border-radius: 8px;';
    wrapper.innerHTML = `
      <img src="${url}" style="max-width:100%; border-radius:8px; margin-bottom:8px; display:block;">
      <div style="display:flex; gap:8px; flex-wrap:wrap; align-items:center;">
        <button class="ocr-extract" style="padding:6px 12px; background:#fff; color:#000; border:none; border-radius:6px; cursor:pointer; font-weight:bold;">
          🔤 Extract Text (OCR)
        </button>
        <button class="ask-about-image" style="padding:6px 12px; background:linear-gradient(90deg,#ffd36b,#ff8a00); color:#000; border:none; border-radius:6px; cursor:pointer; font-weight:bold;">
          💬 Ask AI About Image
        </button>
        <button class="ocr-cancel" style="padding:6px 10px; background:#ff6b6b; color:#fff; border:none; border-radius:6px; cursor:pointer; display:none;">
          ✖ Cancel
        </button>
        <div class="ocr-progress" style="margin-left:8px; font-size:12px; color:#ccc; min-width:120px;"> </div>
      </div>
      <div class="ocr-result" style="margin-top:8px; padding:8px; background:rgba(255,255,255,0.05); border-radius:6px; display:none; color:#dffbf5; font-size:13px;"></div>
    `;

    respDiv.insertBefore(wrapper, respDiv.firstChild);

    // OCR button handler
    const ocrBtn = wrapper.querySelector('.ocr-extract');
    const cancelBtn = wrapper.querySelector('.ocr-cancel');
    const progressEl = wrapper.querySelector('.ocr-progress');
    ocrBtn.addEventListener('click', async () => {
      const resultDiv = wrapper.querySelector('.ocr-result');
      resultDiv.textContent = '⏳ Running OCR...';
      resultDiv.style.display = 'block';
      progressEl.textContent = '';
      cancelBtn.style.display = 'inline-block';
      let cancelled = false;
      // allow cancellation
      cancelBtn.onclick = () => {
        cancelled = true;
        progressEl.textContent = 'Cancelling...';
        // terminate worker if running
        try { if (__tesseractWorker) { __tesseractWorker.terminate(); __tesseractWorker = null; __tesseractLibLoaded = false; } } catch(e){}
        cancelBtn.style.display = 'none';
      };

      try {
        __tesseractProgressCb = (m) => {
          if (m && m.status) {
            const pct = m.progress ? Math.round(m.progress * 100) + '%' : '';
            progressEl.textContent = `${m.status} ${pct}`;
          }
        };

        const ocrText = await runOCR(blob, { progressCb: () => __tesseractProgressCb });
        if (cancelled) {
          resultDiv.textContent = '❌ OCR cancelled';
        } else {
          resultDiv.textContent = ocrText || 'No text found.';
          input.value = (ocrText || '').slice(0, 2000);
        }
      } catch (err) {
        resultDiv.textContent = '❌ OCR failed: ' + (err?.message || err);
      } finally {
        cancelBtn.style.display = 'none';
        progressEl.textContent = '';
        __tesseractProgressCb = null;
      }
    });

    // Ask AI button handler
    wrapper.querySelector('.ask-about-image').addEventListener('click', async () => {
      const question = prompt('Ask a question about this image:');
      if (!question) return;
      respDiv.textContent += (respDiv.textContent ? '\n\n' : '') + `You (image): ${question}\nAI: ...`;

      let ocrText = '';
      try {
        const progressEl = wrapper.querySelector('.ocr-progress');
        __tesseractProgressCb = (m) => {
          if (m && m.status) {
            const pct = m.progress ? Math.round(m.progress * 100) + '%' : '';
            progressEl.textContent = `${m.status} ${pct}`;
          }
        };
        ocrText = await runOCR(blob, { progressCb: () => __tesseractProgressCb });
      } catch (err) {
        console.warn('OCR for image analysis failed:', err);
      } finally {
        __tesseractProgressCb = null;
      }

      // Prepare trimmed text to send to AI for faster responses
  const trimmed = prepareTextForAI(ocrText || '', settings.aiTrimChars || 1500);
      const msgContent = `${question}\n\n[Image pasted - OCR text excerpt]\n${trimmed}`;
      const message = { type: 'USER_CHAT', message: msgContent };

  // Attach AI options (fast mode reduces max tokens)
  message.options = { max_tokens: settings.aiMaxTokens || 256 };

      chrome.runtime.sendMessage(message, (res) => {
        const reply = res?.reply || '❌ No response.';
        respDiv.textContent = respDiv.textContent.replace(/\nAI: \.\.\.$/, `\nAI: ${reply}`);
        respDiv.scrollTop = respDiv.scrollHeight;
      });
    });
  }

  async function runOCR(blob, opts = {}) {
    // opts: { progressCb: ()=>fn }
    // Downscale image to speed up OCR; use settings (if fast mode is enabled, use configured size)
    const maxW = settings.ocrMaxWidth || 1200;
    const maxH = settings.ocrMaxHeight || 1200;
    const quality = settings.ocrQuality || 0.8;
    const smallBlob = await downscaleImage(blob, maxW, maxH, quality);

    // Try local Tesseract worker first
    try {
      const worker = await createOrGetWorker();
      if (worker) {
        const progressCbGetter = opts.progressCb;
        __tesseractProgressCb = progressCbGetter ? progressCbGetter() : null;
        // use settings for downscale fallback if smallBlob didn't already apply
        // worker.recognize returns { data: { text } }
        const { data } = await worker.recognize(smallBlob);
        return data?.text || '';
      }
    } catch (err) {
      console.warn('Local Tesseract failed:', err);
      // If worker was terminated by cancel, make sure lib state is reset
      __tesseractWorker = null;
      __tesseractLibLoaded = false;
    } finally {
      __tesseractProgressCb = null;
    }

    // Try OCR API fallback (also with downscaled image)
    return await ocrWithApi(smallBlob);
  }

  async function loadTesseract() {
    // Deprecated: keep for compatibility but prefer createOrGetWorker
    return !!(window.Tesseract || __tesseractLibLoaded);
  }

  // Create or return an existing persistent Tesseract worker
  async function createOrGetWorker() {
    if (__tesseractWorker) return __tesseractWorker;

    // Load library script if not loaded
    if (!__tesseractLibLoaded) {
      try {
        const localUrl = chrome.runtime.getURL('tesseract/tesseract.min.js');
        await new Promise((resolve, reject) => {
          const s = document.createElement('script');
          s.src = localUrl;
          s.onload = () => resolve();
          s.onerror = () => reject(new Error('Local Tesseract not found'));
          document.head.appendChild(s);
        });
        __tesseractLibLoaded = !!window.Tesseract;
      } catch (e) {
        console.warn('Local Tesseract load failed:', e);
      }
    }

    if (!window.Tesseract) {
      // try CDN fallback
      try {
        const cdnUrl = 'https://cdn.jsdelivr.net/npm/tesseract.js@2.1.5/dist/tesseract.min.js';
        await new Promise((resolve, reject) => {
          const s = document.createElement('script');
          s.src = cdnUrl;
          s.onload = () => resolve();
          s.onerror = () => reject(new Error('CDN Tesseract blocked'));
          document.head.appendChild(s);
        });
      } catch (err) {
        console.warn('CDN Tesseract failed:', err);
      }
    }

    if (!window.Tesseract) return null;

    // Create worker with a logger that forwards to the dynamic callback
    try {
      __tesseractWorker = await Tesseract.createWorker({
        logger: (m) => {
          try {
            if (typeof __tesseractProgressCb === 'function') {
              __tesseractProgressCb(m);
            }
          } catch (e) {}
        },
        corePath: chrome.runtime.getURL('tesseract/tesseract-core.wasm.js'),
        workerPath: chrome.runtime.getURL('tesseract/worker.min.js'),
        langPath: chrome.runtime.getURL('tesseract/lang-data')
      });

      await __tesseractWorker.load();
      await __tesseractWorker.loadLanguage('eng');
      await __tesseractWorker.initialize('eng');
      await __tesseractWorker.setParameters({ tessedit_pageseg_mode: '3' });
      return __tesseractWorker;
    } catch (err) {
      console.warn('Failed to create Tesseract worker:', err);
      __tesseractWorker = null;
      return null;
    }
  }

  async function ocrWithApi(blob) {
    return new Promise((resolve, reject) => {
      chrome.storage.local.get(['ocrApiKey'], async (data) => {
        const apiKey = data.ocrApiKey;
        if (!apiKey) {
          reject(new Error('OCR requires: (1) local Tesseract file or (2) OCR API key in settings'));
          return;
        }

        try {
          // Downscale before converting/encoding to reduce upload size
          const small = await downscaleImage(blob, 1400, 1400, 0.8);
          const reader = new FileReader();
          reader.onload = async () => {
            const form = new FormData();
            form.append('apikey', apiKey);
            form.append('base64Image', reader.result);
            form.append('language', 'eng');
            form.append('isOverlayRequired', 'false');

            const response = await fetch('https://api.ocr.space/parse/image', {
              method: 'POST',
              body: form
            });

            const json = await response.json();
            if (json?.IsErroredOnProcessing) {
              reject(new Error(json.ErrorMessage?.[0] || 'OCR API error'));
              return;
            }

            const text = json?.ParsedResults?.[0]?.ParsedText || '';
            resolve(text);
          };

          reader.onerror = () => reject(new Error('Failed to read image'));
          reader.readAsDataURL(small);
        } catch (err) {
          reject(err);
        }
      });
    });
  }

  // Downscale image blob using canvas; returns a new Blob (image/jpeg) for faster processing
  async function downscaleImage(blob, maxW = 1200, maxH = 1200, quality = 0.8) {
    try {
      const imageBitmap = await createImageBitmap(blob);
      let { width, height } = imageBitmap;
      const ratio = Math.min(1, Math.min(maxW / width, maxH / height));
      if (ratio === 1) {
        // no need to resize
        return blob;
      }
      const cw = Math.max(1, Math.floor(width * ratio));
      const ch = Math.max(1, Math.floor(height * ratio));
      const canvas = document.createElement('canvas');
      canvas.width = cw;
      canvas.height = ch;
      const ctx = canvas.getContext('2d');
      ctx.drawImage(imageBitmap, 0, 0, cw, ch);
      return await new Promise((resolve) => canvas.toBlob((b) => resolve(b), 'image/jpeg', quality));
    } catch (err) {
      // fallback - return original
      return blob;
    }
  }

  // Prepare text snippet for AI: trim intelligently to maxChars, keep start and end if trimmed
  function prepareTextForAI(text, maxChars = 1500) {
    if (!text) return '';
    if (text.length <= maxChars) return text;
    // keep first 1200 chars and last 200 chars
    const head = text.slice(0, Math.max(1000, maxChars - 300));
    const tail = text.slice(-200);
    return head + "\n\n[...snip...]\n\n" + tail;
  }

  // Send handler
  if (sendBtn) {
    sendBtn.addEventListener('click', handleSend);
  }

  // Enter key
  if (input) {
    input.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        handleSend();
      }
    });
  }

  function handleSend() {
    const val = input.value.trim();
    if (!val) return;

    respDiv.textContent += (respDiv.textContent ? '\n\n' : '') + `You: ${val}\nAI: ...`;
    input.value = '';

    chrome.storage.local.get(['rag_docs'], (data) => {
      const docs = data.rag_docs || [];
      let context = '';

      if (currentChatContext) {
        context += `Attached PDF:\n${currentChatContext}\n\n`;
      }

      if (docs.length > 0) {
        const scored = [];
        const queryTokens = tokenize(val);
        for (const doc of docs) {
          for (const chunk of doc.chunks) {
            const score = scoreChunk(queryTokens, chunk);
            scored.push({ score, chunk, docName: doc.name });
          }
        }
        scored.sort((a,b) => b.score - a.score);
        const top = scored.slice(0,5).filter(s => s.score > 0);
        if (top.length > 0) {
          context += top.map(t => `Source: ${t.docName}\n${t.chunk}`).join('\n\n');
        }
      }

      const message = { type: 'USER_CHAT', message: val };
      if (context) message.ragContext = context;
      // Attach fast-mode AI options
      message.options = { max_tokens: settings.fastMode ? (settings.aiMaxTokens || 256) : (settings.aiMaxTokens || 800) };

      chrome.runtime.sendMessage(message, (res) => {
        const reply = res?.reply || '❌ No response.';
        respDiv.textContent = respDiv.textContent.replace(/\nAI: \.\.\.$/, `\nAI: ${reply}`);
        respDiv.scrollTop = respDiv.scrollHeight;
      });
    });
  }

  function tokenize(s) {
    return s.toLowerCase().replace(/[^a-z0-9 ]+/g,' ').split(/\s+/).filter(Boolean);
  }

  function scoreChunk(tokens, chunk) {
    const ct = tokenize(chunk);
    const set = new Set(ct);
    return tokens.reduce((sum, t) => sum + (set.has(t) ? 1 : 0), 0);
  }

  chrome.runtime.onMessage.addListener((msg) => {
    if (msg?.type === "SHOW_RESPONSE") {
      respDiv.textContent = msg.response || "No response.";
    }
  });

  try {
    const iconEl = document.getElementById('hai-icon');
    if (iconEl) iconEl.src = chrome.runtime.getURL("icon-128.png");
  } catch (e) {}
})();
