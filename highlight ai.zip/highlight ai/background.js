// background.js — Highlight AI with Mistral + PDF support + retry
console.log("Highlight AI — background starting");

const OPENROUTER_ENDPOINT = "https://openrouter.ai/api/v1/chat/completions";
const MODEL_ID = "mistralai/mistral-small-3.2-24b-instruct:free";

// ===== Helper Functions =====
function getStorage(keys) {
  return new Promise((resolve) => chrome.storage.local.get(keys, resolve));
}

// Safer fetch with retry to prevent rate-limit errors
async function fetchWithRetry(url, options, retries = 2) {
  for (let i = 0; i <= retries; i++) {
    try {
      const res = await fetch(url, options);
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const data = await res.json();
      if (data?.error) throw new Error(data.error.message);
      return data;
    } catch (err) {
      console.warn(`Fetch attempt ${i + 1} failed:`, err.message);
      if (i === retries) throw err;
      await new Promise((r) => setTimeout(r, 1500)); // wait 1.5 sec before retry
    }
  }
}

// ===== Context Menu =====
chrome.runtime.onInstalled.addListener(() => {
  try {
    chrome.contextMenus.create({
      id: "askAI",
      title: "Ask AI",
      contexts: ["selection"]
    });
    chrome.contextMenus.create({
      id: "summarizePDF",
      title: "Summarize this PDF",
      contexts: ["page"]
    });
    console.log("Context menu created");
  } catch (e) {
    console.warn("Menu creation error:", e);
  }
});

chrome.runtime.onStartup.addListener(() => {
  try {
    chrome.contextMenus.create({
      id: "askAI",
      title: "Ask AI",
      contexts: ["selection"]
    });
    chrome.contextMenus.create({
      id: "summarizePDF",
      title: "Summarize this PDF",
      contexts: ["page"]
    });
  } catch (e) {}
});

// ===== Handle Menu Clicks =====
chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (!tab || tab.id === -1) return;

  // get API key
  const storage = await getStorage(["apiKey"]);
  const apiKey = storage.apiKey;
  if (!apiKey) {
    chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: () => alert("Please open Highlight AI → Settings and save your OpenRouter API key.")
    });
    return;
  }

  // CASE 1: Ask AI on selected text
  if (info.menuItemId === "askAI") {
    const selectedText = (info.selectionText || "").trim();
    if (!selectedText) return;

    const payload = {
      model: MODEL_ID,
      messages: [
        {
          role: "system",
          content: "You are Highlight AI, a helpful assistant that explains or answers selected text clearly and concisely."
        },
        { role: "user", content: selectedText }
      ],
      max_tokens: 400
    };

    let aiText = "❌ No response from AI.";
    try {
      const data = await fetchWithRetry(OPENROUTER_ENDPOINT, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${apiKey}`
        },
        body: JSON.stringify(payload)
      });

      if (data?.choices?.[0]?.message?.content)
        aiText = data.choices[0].message.content.trim();
      else if (data?.output_text)
        aiText = data.output_text.trim();
    } catch (err) {
      aiText = `❌ Error contacting AI: ${err.message}`;
    }

    try {
      await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        files: ["sidebar.js"]
      });
    } catch (err) {
      console.warn("Sidebar already loaded, skipping injection:", err);
    }

    chrome.tabs.sendMessage(tab.id, {
      type: "SHOW_RESPONSE",
      selectedText,
      response: aiText
    });
  }

  // CASE 2: Summarize PDF
  if (info.menuItemId === "summarizePDF") {
    chrome.tabs.sendMessage(tab.id, { type: "REQUEST_PDF_SUMMARY" });
  }
});

// ===== Chat message from sidebar =====
// Central message handler (USER_CHAT, HIGHLIGHT_TEXT, PDF_TEXT_EXTRACTED)
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || !msg.type) return;

  // USER_CHAT: request from sidebar's chat input
  if (msg.type === "USER_CHAT") {
    (async () => {
      const storage = await getStorage(["apiKey"]);
      const apiKey = storage.apiKey;
      if (!apiKey) {
        sendResponse({ reply: "❌ No API key set (Options → paste key)." });
        return;
      }

      // If RAG context provided, include it in the prompt (prepend)
      let userContent = msg.message;
      if (msg.ragContext) {
        userContent = `Use the following extracted document excerpts to answer the question. If irrelevant, say so.\n\n${msg.ragContext}\n\nQuestion: ${msg.message}`;
      }

      const payload = {
        model: MODEL_ID,
        messages: [{ role: "user", content: userContent }],
        max_tokens: msg.options?.max_tokens || 800
      };

      try {
        const data = await fetchWithRetry(OPENROUTER_ENDPOINT, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "Authorization": `Bearer ${apiKey}`
          },
          body: JSON.stringify(payload)
        });

        let reply = "❌ No response from AI.";
        if (data?.choices?.[0]?.message?.content)
          reply = data.choices[0].message.content.trim();
        else if (data?.output_text)
          reply = data.output_text.trim();

        sendResponse({ reply });
      } catch (err) {
        sendResponse({ reply: `❌ Error contacting AI: ${err.message}` });
      }
    })();
    return true;
  }

  // HIGHLIGHT_TEXT: content script sent selected text (on mouseup)
  if (msg.type === "HIGHLIGHT_TEXT") {
    (async () => {
      const storage = await getStorage(["apiKey"]);
      const apiKey = storage.apiKey;
      const tabId = sender?.tab?.id;
      if (!apiKey || !tabId) return;

      const payload = {
        model: MODEL_ID,
        messages: [
          { role: "system", content: "You are Highlight AI, a helpful assistant that explains or answers selected text clearly and concisely." },
          { role: "user", content: msg.text }
        ],
        max_tokens: 400
      };

      try {
        const data = await fetchWithRetry(OPENROUTER_ENDPOINT, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "Authorization": `Bearer ${apiKey}`
          },
          body: JSON.stringify(payload)
        });

        let aiText = "❌ No response from AI.";
        if (data?.choices?.[0]?.message?.content)
          aiText = data.choices[0].message.content.trim();
        else if (data?.output_text)
          aiText = data.output_text.trim();

        chrome.tabs.sendMessage(tabId, { type: "SHOW_RESPONSE", selectedText: msg.text, response: aiText });
      } catch (err) {
        chrome.tabs.sendMessage(tabId, { type: "SHOW_RESPONSE", selectedText: msg.text, response: `❌ Error contacting AI: ${err.message}` });
      }
    })();
    return; // no sendResponse expected
  }

  // PDF_TEXT_EXTRACTED: content script extracted PDF text and sent it here for summarization
  if (msg.type === "PDF_TEXT_EXTRACTED") {
    (async () => {
      const storage = await getStorage(["apiKey"]);
      const apiKey = storage.apiKey;
      const tabId = sender?.tab?.id;
      if (!apiKey || !tabId) return;

      if (msg.error) {
        chrome.tabs.sendMessage(tabId, { type: "SHOW_RESPONSE", selectedText: "PDF Summary", response: `❌ Could not extract PDF text: ${msg.error}` });
        return;
      }

      // Ask AI to summarize long text concisely
      const userContent = `Summarize the following PDF content in clear bullet points (short):\n\n${msg.text.substring(0, 20000)}`;
      const payload = {
        model: MODEL_ID,
        messages: [
          { role: "system", content: "You are Highlight AI, summarizer for PDF content. Produce concise bullet-point summaries." },
          { role: "user", content: userContent }
        ],
        max_tokens: 800
      };

      try {
        const data = await fetchWithRetry(OPENROUTER_ENDPOINT, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "Authorization": `Bearer ${apiKey}`
          },
          body: JSON.stringify(payload)
        });

        let aiText = "❌ No response from AI.";
        if (data?.choices?.[0]?.message?.content)
          aiText = data.choices[0].message.content.trim();
        else if (data?.output_text)
          aiText = data.output_text.trim();

        chrome.tabs.sendMessage(tabId, { type: "SHOW_RESPONSE", selectedText: "PDF Summary", response: aiText });
      } catch (err) {
        chrome.tabs.sendMessage(tabId, { type: "SHOW_RESPONSE", selectedText: "PDF Summary", response: `❌ Error contacting AI: ${err.message}` });
      }
    })();
    return;
  }
});
