let sidebarVisible = false;

// Create Ask AI button
const askBtn = document.createElement("button");
askBtn.textContent = "✨ Ask AI";
askBtn.id = "askAIButton";
askBtn.style.cssText = `
  position: fixed;
  bottom: 20px;
  right: 20px;
  z-index: 9999;
  background: #7c3aed;
  color: white;
  border: none;
  border-radius: 25px;
  padding: 12px 18px;
  cursor: pointer;
  font-size: 16px;
  box-shadow: 0 3px 8px rgba(0,0,0,0.3);
`;
document.body.appendChild(askBtn);

askBtn.addEventListener("click", () => {
  try {
    if (!sidebarVisible) {
      openSidebar();
    } else {
      closeSidebar();
    }
  } catch (err) {
    if (err.message.includes('Extension context invalidated')) {
      console.warn('Extension reloaded, please refresh the page');
      alert('Extension was updated. Please refresh the page.');
    }
  }
});

function openSidebar() {
  try {
    const url = window.location.href || '';
    const isPdf = /\.pdf(\?|#|$)/i.test(url) || document.contentType?.includes?.('pdf') || document.querySelector('embed[type="application/pdf"], iframe[src*=".pdf"]');
    
    sidebarVisible = true;
    const iframe = document.createElement("iframe");
    iframe.src = chrome.runtime.getURL("sidebar.html");
    iframe.id = "aiSidebar";
    
    // For PDFs, we need to ensure the sidebar doesn't overlap with PDF controls
    // and stays on top of the PDF viewer
    if (isPdf) {
      iframe.style.cssText = `
        position: fixed;
        top: 0;
        right: 0;
        width: 380px;
        height: 100%;
        z-index: 2147483647;
        border: none;
        background: linear-gradient(180deg, rgba(4,10,13,0.96), rgba(2,6,8,0.98));
        box-shadow: -2px 0 10px rgba(0,0,0,0.3);
      `;
      
      // Adjust PDF viewer size
      const pdfViewer = document.querySelector('embed[type="application/pdf"], iframe[src*=".pdf"]');
      if (pdfViewer) {
        pdfViewer.style.width = 'calc(100% - 380px)';
      }
    } else {
      iframe.style.cssText = `
        position: fixed;
        top: 0;
        right: 0;
        width: 380px;
        height: 100%;
        z-index: 99999;
        border: none;
        box-shadow: -2px 0 10px rgba(0,0,0,0.3);
      `;
    }
    
    document.body.appendChild(iframe);
  } catch (err) {
    console.error('Error opening sidebar:', err);
    if (err.message.includes('Extension context invalidated')) {
      sidebarVisible = false;
      alert('Extension context was invalidated. Please refresh the page.');
    }
  }
}

function closeSidebar() {
  sidebarVisible = false;
  const iframe = document.getElementById("aiSidebar");
  if (iframe) {
    // Reset PDF viewer width if it was adjusted
    const pdfViewer = document.querySelector('embed[type="application/pdf"], iframe[src*=".pdf"]');
    if (pdfViewer) {
      pdfViewer.style.width = '100%';
    }
    iframe.remove();
  }
}

// Handle text highlight
document.addEventListener("mouseup", () => {
  try {
    const selectedText = window.getSelection().toString().trim();
    if (selectedText) {
      chrome.runtime.sendMessage({ type: "HIGHLIGHT_TEXT", text: selectedText });
    }
  } catch (err) {
    console.warn('Error sending highlight:', err);
  }
});

// Listen for AI responses
chrome.runtime.onMessage.addListener((msg) => {
  try {
    const iframe = document.getElementById("aiSidebar");
    if (!iframe) return;
    iframe.contentWindow.postMessage(msg, "*");
  } catch (err) {
    console.warn('Error posting message to iframe:', err);
  }
});

// Listen for messages from sidebar iframe (e.g., close request)
window.addEventListener('message', (e) => {
  try {
    const data = e?.data;
    if (!data || data.type !== 'CLOSE_SIDEBAR') return;
    const iframe = document.getElementById('aiSidebar');
    if (iframe) iframe.remove();
    sidebarVisible = false;
  } catch (err) {
    console.warn('Error handling message from sidebar iframe', err);
  }
});

// Handle PDF summary request from background (context menu)
chrome.runtime.onMessage.addListener(async (msg, sender, sendResponse) => {
  if (!msg || msg.type !== "REQUEST_PDF_SUMMARY") return;
  try {
    const url = window.location.href;
    // Quick check: only attempt when URL looks like a PDF or page displays PDF
    if (!/\.pdf(\?|#|$)/i.test(url) && !document.contentType?.includes("pdf") && !document.querySelector('embed[type="application/pdf"], iframe[src*=".pdf"]')) {
      // Still try: some PDF viewers don't show .pdf in URL, proceed carefully
    }

    // Dynamically import pdfjs and extract text
    const pdfjsLib = await import(chrome.runtime.getURL('pdfjs/pdf.mjs'));
    // Ensure worker path is set so pdf.js can spawn worker correctly
    try {
      if (pdfjsLib.GlobalWorkerOptions) {
        pdfjsLib.GlobalWorkerOptions.workerSrc = chrome.runtime.getURL('pdfjs/pdf.worker.mjs');
      }
    } catch (e) {
      console.warn('Could not set pdfjs workerSrc', e);
    }
    const loadingTask = pdfjsLib.getDocument(url);
    const pdf = await loadingTask.promise;
    let text = "";
    for (let i = 1; i <= pdf.numPages; i++) {
      try {
        const page = await pdf.getPage(i);
        const content = await page.getTextContent();
        text += content.items.map(it => it.str).join(" ") + "\n";
      } catch (e) {
        console.warn('Failed to extract page', i, e);
      }
    }

    // Send extracted text to background for summarization
    try {
      chrome.runtime.sendMessage({ type: "PDF_TEXT_EXTRACTED", text });
    } catch (err) {
      console.warn('Error sending PDF text:', err);
    }
  } catch (err) {
    try {
      chrome.runtime.sendMessage({ type: "PDF_TEXT_EXTRACTED", error: err.message });
    } catch (e) {
      console.warn('Error sending PDF error:', e);
    }
  }
});
