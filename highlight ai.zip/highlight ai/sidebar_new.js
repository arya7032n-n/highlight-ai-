// sidebar.js - injected UI with improved close handling
(function(){
  if (window.__highlightAI_loaded) return;
  window.__highlightAI_loaded = true;

  // remove existing
  const prev = document.getElementById("highlight-ai-root");
  if (prev) prev.remove();

  // root container
  const root = document.createElement("div");
  root.id = "highlight-ai-root";
  root.innerHTML = `
    <div id="hai-header">
      <div style="display:flex;align-items:center;gap:10px;">
        <img src="" id="hai-icon" alt="">
        <div>
          <div style="font-weight:700;font-size:16px">Highlight AI</div>
          <div style="font-size:12px;color:#9be7e0">Explain highlights &bull; chat with AI</div>
        </div>
      </div>
      <div>
        <button id="hai-close" title="Close">Close</button>
      </div>
    </div>

    <div id="hai-body">
      <div id="hai-selected"></div>
      <div id="hai-response"></div>
    </div>

    <div class="input-row">
      <input id="hai-input" placeholder="Type your question...">
      <button id="hai-send">Ask</button>
    </div>
  `;

  // Add styles
  const style = document.createElement('style');
  style.textContent = `
    #highlight-ai-root {
      position: fixed;
      top: 0;
      right: 0;
      width: 380px;
      height: 100vh;
      background: linear-gradient(180deg, rgba(4,10,13,0.96), rgba(2,6,8,0.98));
      color: #dffbf5;
      z-index: 2147483647;
      font-family: Inter, Arial, sans-serif;
      display: flex;
      flex-direction: column;
      box-shadow: -6px 0 30px rgba(0,0,0,0.6);
    }

    #hai-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 14px 16px;
      border-bottom: 1px solid rgba(255,255,255,0.02);
    }

    #hai-close {
      background: #ff6b6b;
      border: none;
      padding: 8px 10px;
      border-radius: 8px;
      cursor: pointer;
      font-weight: 700;
      color: #000;
    }

    #hai-body {
      flex: 1;
      overflow: auto;
      padding: 14px;
    }

    .input-row {
      padding: 12px;
      border-top: 1px solid rgba(255,255,255,0.02);
      display: flex;
      gap: 8px;
      align-items: center;
    }
  `;
  document.head.appendChild(style);

  // Set up close button immediately after creating root
  const closeBtn = root.querySelector('#hai-close');
  if (closeBtn) {
    closeBtn.addEventListener('click', handleClose);
  }

  // Append root to page
  document.documentElement.appendChild(root);

  // Close handler function
  function handleClose() {
    // Try to message parent if we're in an iframe
    if (window !== window.top) {
      try {
        parent.postMessage({ type: 'CLOSE_SIDEBAR' }, '*');
        return;
      } catch (e) {
        console.warn('Could not message parent:', e);
      }
    }

    // If we're injected into the page directly
    const root = document.getElementById('highlight-ai-root');
    if (root) {
      try {
        root.remove();
        window.__highlightAI_loaded = false;
        return;
      } catch (e) {
        console.warn('Could not remove root:', e);
      }
    }

    // Last resort for standalone windows
    try {
      window.close();
    } catch (e) {
      console.warn('Could not close window:', e);
    }
  }

  // Listen for external close requests
  window.addEventListener('message', (e) => {
    if (e.data?.type === 'CLOSE_SIDEBAR') {
      handleClose();
    }
  });

  // Rest of your sidebar functionality here...
  // (copy the rest of the original sidebar.js content)
})();