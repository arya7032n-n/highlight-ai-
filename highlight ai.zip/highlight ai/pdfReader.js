// pdfReader.js — extract full text from PDFs
console.log("PDF Reader loaded");

async function extractTextFromPDF(url) {
  const pdfjsLib = await import(chrome.runtime.getURL('pdfjs/pdf.mjs'));
  const loadingTask = pdfjsLib.getDocument(url);
  const pdf = await loadingTask.promise;
  let text = "";

  for (let i = 1; i <= pdf.numPages; i++) {
    const page = await pdf.getPage(i);
    const content = await page.getTextContent();
    text += content.items.map(it => it.str).join(" ") + "\n";
  }

  return text;
}

chrome.runtime.onMessage.addListener(async (msg, sender, sendResponse) => {
  if (msg.type !== "EXTRACT_PDF_TEXT") return;
  try {
    const text = await extractTextFromPDF(msg.pdfUrl);
    sendResponse({ success: true, text });
  } catch (err) {
    sendResponse({ success: false, error: err.message });
  }
});
